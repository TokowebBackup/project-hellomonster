<table width="100%" cellpadding="0" cellspacing="0" style="font-family: Arial, sans-serif; color: #333;">
    <tr>
        <td align="center" style="padding: 40px;">
            <img src="<?= base_url('assets/img/Hello-Monster_Branding-Phase-1 - 1-_page-00071e5.png') ?>" alt="Hellomonster" width="150" style="margin-bottom: 20px;" />
            <h2 style="margin: 0 0 10px;"><?= lang('Membership.email_waiver_completed_title') ?></h2>
            <p style="font-size: 16px; line-height: 1.5;">
                <?= lang('Membership.email_waiver_completed_message') ?>
            </p>
            <p style="margin-top: 40px;"><?= lang('Membership.email_greeting_closing') ?></p>
        </td>
    </tr>
</table>